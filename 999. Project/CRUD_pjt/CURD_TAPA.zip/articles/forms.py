from django import forms
from .models import Article, Review


class ArticleForm(forms.ModelForm):
    class Meta:
        model = Article
        fields = ('title', 'content',)


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ('content',)