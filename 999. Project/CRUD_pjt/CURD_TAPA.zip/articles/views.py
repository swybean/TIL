from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Article, Review
from .forms import ArticleForm, ReviewForm

# Create your views here.

def index(request):
    articles = Article.objects.all()
    context = {
        'articles': articles
    }
    return render(request, 'articles/index.html', context)

def detail(request, pk):
    article = Article.objects.get(pk=pk)
    reviews = article.review_set.all()
    context = {
        'article': article,
        'reviews': reviews,
    }
    return render(request, 'articles/detail.html', context)

@login_required
def create(request):
    if request.method == 'POST':
        form = ArticleForm(request.POST)
        if form.is_valid():
            article = form.save(commit=False)
            article.user = request.user
            article.save()
            return redirect('articles:detail', article.pk)
    else:
        form = ArticleForm()
    context = {
        'form': form,
    }
    return render(request, 'articles/create.html', context)

@login_required
def delete(request, pk):
    article = Article.objects.get(pk=pk)
    if request.user == article.user:
        article.delete()
    return redirect('articles:index')


@login_required
def update(request, pk):
    article = Article.objects.get(pk=pk)
    if request.user == article.user:
        if request.method == 'POST':
            form = ArticleForm(request.POST, instance=article)
            if form.is_valid():
                form.save()
                return redirect('articles:detail', article.pk)
        else:
            form = ArticleForm(instance=article)
    else:
        return redirect('articles:index')
    context = {
        'article': article,
        'form': form,
    }
    return render(request, 'articles/update.html', context)

@login_required
def review_create(request, article_pk):
    article = Article.objects.get(pk=article_pk)
    reviews = article.review_set.all()
    review_form = ReviewForm(request.POST)

    if review_form.is_valid():
        review = review_form.save(commit=False)
        review.article = article
        review.user = request.user
        review.save()
        return redirect('articles:detail', article.pk)
    
    context = {
        'review_form': review_form,
        'article': article,
        'reviews': reviews,
    }
    return render(request, 'articles/detail.html', context)

@login_required
def review_delete(request, article_pk, review_pk):
    review = Review.objects.get(pk=review_pk)
    
    if request.user == review.user:
        review.delete()
    return redirect('articles:detail', article_pk)

